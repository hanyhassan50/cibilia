<?php

namespace Cibilia\Summary\Controller\Index;

use Cibilia\Summary\Controller\SummaryInterface;

class View extends \Cibilia\Summary\Controller\AbstractController\View implements SummaryInterface
{

}
