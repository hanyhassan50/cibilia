<?php
namespace Cibilia\Cibilians\Block;
/**
* Baz block
*/
class Recommend
    extends \Magento\Framework\View\Element\Template
{
    // public function getTitle()
    // {
        // return "Advertisers";
    // }
    // protected $_template = 'advertisers.phtml';

    /**
   
    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        // $this->pageConfig->getTitle()->set(__('My Orders'));
    }

   
}
