<?php
/**
 *
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Cibilia\Commission\Controller\Index;

use Magento\Sales\Controller\OrderInterface;

class Vieworder extends \Magento\Sales\Controller\AbstractController\View implements OrderInterface
{
}
