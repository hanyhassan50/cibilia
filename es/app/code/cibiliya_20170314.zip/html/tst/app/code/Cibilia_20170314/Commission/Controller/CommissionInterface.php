<?php

namespace Cibilia\Commission\Controller;

use Magento\Framework\App\ActionInterface;

interface CommissionInterface extends ActionInterface
{
}
