<?php

namespace Cibilia\Commission\Controller\Index;

use Cibilia\Commission\Controller\CommissionInterface;

class View extends \Cibilia\Commission\Controller\AbstractController\View implements CommissionInterface
{

}
