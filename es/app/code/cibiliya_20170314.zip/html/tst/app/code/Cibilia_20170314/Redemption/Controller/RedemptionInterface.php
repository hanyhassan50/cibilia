<?php

namespace Cibilia\Redemption\Controller;

use Magento\Framework\App\ActionInterface;

interface RedemptionInterface extends ActionInterface
{
}
