<?php

namespace Cibilia\Summary\Controller;

use Magento\Framework\App\ActionInterface;

interface SummaryInterface extends ActionInterface
{
}
