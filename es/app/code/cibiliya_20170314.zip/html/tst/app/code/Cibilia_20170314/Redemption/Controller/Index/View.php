<?php

namespace Cibilia\Redemption\Controller\Index;

use Cibilia\Redemption\Controller\RedemptionInterface;

class View extends \Cibilia\Redemption\Controller\AbstractController\View implements RedemptionInterface
{

}
