<?php
namespace Cibilia\Cibilians\Block;

/**
* Baz block
*/
class Advertisers
    extends \Magento\Framework\View\Element\Template
{
    // public function getTitle()
    // {
        // return "Advertisers";
    // }
}