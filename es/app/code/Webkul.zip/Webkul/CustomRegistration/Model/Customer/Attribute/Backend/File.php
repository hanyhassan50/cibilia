<?php

namespace Webkul\CustomRegistration\Model\Customer\Attribute\Backend;

class File extends \Webkul\CustomRegistration\Model\Customer\Attribute\Backend\Image
{
    /**
     * @var string
     */
    protected $_type = 'file';
}
