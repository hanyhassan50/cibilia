<?php

namespace Webkul\CustomRegistration\Block\Adminhtml\Attribute\Edit\Tab;

class Options extends \Webkul\CustomRegistration\Block\Adminhtml\Attribute\Edit\Tab\AbstractOptions
{
}
